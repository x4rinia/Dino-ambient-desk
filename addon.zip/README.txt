# Dino Desk - Zusaetzliche Begleiter-Addons (addon.zip)

Dieses Paket enthaelt 10 zusaetzliche Begleiter fuer dein Dino-Widget-Desk:

1. Biene (biene.companion.json) - Flotte kleine Honigbiene
2. Diddl (diddl.companion.json) - Niedliche Springmaus
3. Elfe (elfe.companion.json) - Zauberhafte Waldelfe
4. Mops-Welpe (hund1.companion.json) - Verspielter Mops
5. Terrier (hund2.companion.json) - Froehlicher kleiner Terrier
6. Katze Ginger (katze1.companion.json) - Gemuetliche getigerte Katze
7. Katze Tuxedo (katze2.companion.json) - Edle schwarz-weisse Katze
8. Optimus (optimus.companion.json) - Legendärer Transformer
9. Bumblebee (robot.companion.json) - Gelber Roboter
10. Troll (troll.companion.json) - Kleiner Waldtroll

## Installation:
1. Oeffne die Einstellungen im Dino-Widget-Desk.
2. Klicke im Abschnitt 'Begleiter' auf 'Begleiter auswaehlen' und dann auf 'Ordner oeffnen'.
3. Kopiere die gewuenschten .companion.json Dateien einfach in diesen geoeffneten Ordner.
4. Fertig! Die Begleiter werden sofort erkannt und stehen zur Auswahl bereit.
